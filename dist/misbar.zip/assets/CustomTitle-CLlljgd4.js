import{u as o,j as s}from"./index-CR_WAB_6.js";const i=({title:t})=>{const{t:e}=o();return s.jsx("div",{className:"Custom_Title",children:s.jsx("p",{children:e(t)})})};export{i as C};
